# Entregable - Colegio Integridad

## Datos del informe

- **Proyecto:** Colegio Integridad
- **Dominio evaluado:** `colegiointegridad.edu.pe`
- **Subdominio evaluado:** `aula.colegiointegridad.edu.pe`
- **Fecha:** `2026-05-11`
- **Autor / equipo:** `Samuel`
- **Clasificación:** Uso interno

## 1. Resumen ejecutivo

La infraestructura evaluada presenta una **exposición alta** por la publicación de servicios administrativos, correo y base de datos hacia Internet. La combinación de `cPanel`, `Webmail`, `MySQL`, `FTP` y WordPress accesibles desde el exterior incrementa de forma material la probabilidad de abuso de credenciales, acceso no autorizado y afectación operativa.

Adicionalmente, el LMS `Moodle` opera sobre `PHP 7.4.33`, una versión fuera de soporte, lo que añade deuda técnica y riesgo acumulado.

### Conclusión ejecutiva

El entorno no muestra necesariamente compromiso activo, pero sí una **superficie de ataque demasiado amplia**. La prioridad inmediata es reducir la exposición crítica y endurecer los controles de autenticación y perímetro.

## 2. Alcance

Se evaluaron los siguientes activos:

- `149.56.147.198` — servidor principal (OVH, AS16276)
- `51.161.45.249` — LMS / Moodle (OVH, AS16276)
- subdominios vivos asociados al dominio principal

## 3. Metodología

Se aplicaron las siguientes técnicas de reconocimiento y validación:

- DNS / NS lookup
- Whois
- enumeración de subdominios (gobuster DNS)
- fingerprinting web (whatweb)
- escaneo de puertos y servicios (nmap -sV -sC)
- verificación de respuestas HTTP/HTTPS
- revisión de tecnología detectada
- análisis manual de exposición

La evaluación fue observacional. No se ejecutó explotación destructiva ni autenticación sobre cuentas reales.

## 4. Superficie expuesta

### Servidor principal `149.56.147.198` (h3.a1center.net)

Rol observado:
- WordPress 6.9.4
- cPanel / Webmail (Roundcube)
- correo (Dovecot + Exim)
- FTP (Pure-FTPd)
- MySQL (MariaDB 11.4.10)
- DNS (PowerDNS 4.9.5)

Puertos y servicios detectados:

| Puerto | Estado | Servicio | Versión / Detalle |
|--------|--------|----------|-------------------|
| 21/tcp | open | FTP | Pure-FTPd |
| 22/tcp | closed | SSH | - |
| 53/tcp | open | DNS | PowerDNS 4.9.5 |
| 80/tcp | open | HTTP | openresty/1.29.2.3 (403 Forbidden) |
| 110/tcp | open | POP3 | Dovecot |
| 143/tcp | open | IMAP | Dovecot |
| 443/tcp | open | HTTPS | openresty/1.29.2.3 — cert EXPIRADO de autoboutiqueml.com |
| 465/tcp | open | SMTPS | Exim 4.99.2 |
| 587/tcp | open | SMTP | Exim 4.99.2 (STARTTLS) |
| 993/tcp | open | IMAPS | Dovecot |
| 995/tcp | open | POP3S | Dovecot |
| 2083/tcp | open | **cPanel** | Confirmado — cookies cpsession, cprelogin |
| 2096/tcp | open | **Webmail** | Roundcube confirmado — cookies webmailsession |
| 3306/tcp | open | **MySQL** | MariaDB 11.4.10 🚨 EXPUESTO |

### LMS `51.161.45.249`

Rol observado:
- Moodle / aula virtual
- LiteSpeed
- PHP 7.4.33
- HTTP/3 (alt-svc h3)

Puertos relevantes (todos filtrados por firewall):

| Puerto | Estado | Servicio |
|--------|--------|----------|
| 22/tcp | filtered | SSH |
| 80/tcp | filtered | HTTP |
| 443/tcp | filtered | HTTPS |
| 3306/tcp | filtered | MySQL |

## 5. Subdominios vivos

Descubiertos vía gobuster DNS + validación manual:

| Subdominio | IP | Notas |
|---|---|---|
| `colegiointegridad.edu.pe` | 149.56.147.198 | Principal (WordPress) |
| `www.colegiointegridad.edu.pe` | 149.56.147.198 | Redirige al principal |
| `mail.colegiointegridad.edu.pe` | 149.56.147.198 | Correo |
| `webmail.colegiointegridad.edu.pe` | 149.56.147.198 | Roundcube login |
| `cpanel.colegiointegridad.edu.pe` | 149.56.147.198 | Panel de control |
| `cpcalendars.colegiointegridad.edu.pe` | 149.56.147.198 | cPanel Calendar |
| `cpcontacts.colegiointegridad.edu.pe` | 149.56.147.198 | cPanel Contacts |
| `webdisk.colegiointegridad.edu.pe` | 149.56.147.198 | WebDisk (Basic Auth) |
| `autodiscover.colegiointegridad.edu.pe` | 149.56.147.198 | Autodiscover |
| `ftp.colegiointegridad.edu.pe` | 149.56.147.198 | FTP |
| `aula.colegiointegridad.edu.pe` | 51.161.45.249 | Moodle LMS |

**Total: 11 subdominios vivos en 2 IPs**

## 6. Hallazgos críticos

### 6.1 cPanel expuesto públicamente

`cpanel.colegiointegridad.edu.pe` responde desde Internet en puerto `2083/tcp` con acceso al panel administrativo. Confirmado vía nmap: responde con cookies de sesión (`cpsession`, `cprelogin`) y contenido HTML del login de cPanel.

**Impacto técnico:**
- amplía la superficie de administración
- facilita fuerza bruta y credential stuffing
- incrementa el riesgo de takeover del hosting

**Impacto operativo:**
- compromete sitios, correo y configuración del servidor
- puede derivar en cambios no autorizados de infraestructura

**Score:** 9.5/10

### 6.2 Webmail expuesto públicamente

`webmail.colegiointegridad.edu.pe` responde en puerto `2096/tcp` con login de Roundcube accesible públicamente. Confirmado vía nmap: cookies `webmailsession`, `roundcube_sessid`, `roundcube_cookies`.

**Impacto técnico:**
- expone autenticación de correo a Internet
- habilita ataques dirigidos contra buzones
- puede usarse para pivoteo interno si hay credenciales válidas

**Impacto operativo:**
- afecta confidencialidad de cuentas institucionales
- aumenta riesgo de phishing y abuso de correo

**Score:** 9.0/10

### 6.3 MySQL (MariaDB) expuesto públicamente

El puerto `3306/tcp` aparece abierto en el servidor principal (`149.56.147.198`). Versión detectada: **MariaDB 11.4.10-log**. El handshake de MySQL responde públicamente: `thread_id: 395557`, capacidades completas (`SupportsTransactions`, `SupportsAuthPlugins`, etc.), lo que permite conexión sin autenticación previa.

**Impacto técnico:**
- base de datos visible en red pública
- alta exposición a abuso de credenciales y enumeración
- riesgo crítico si credenciales reutilizadas son válidas
- fingerprinting de versión posible sin autenticar

**Impacto operativo:**
- compromete datos de WordPress y Moodle
- riesgo directo sobre confidencialidad e integridad

**Score:** 10/10

### 6.4 FTP expuesto públicamente

`21/tcp` está abierto en el servidor principal.

**Impacto técnico:**
- protocolo legado y débil frente a abuso
- mala opción para administración expuesta
- favorece credenciales débiles y transferencia insegura

**Impacto operativo:**
- facilita alteración de archivos
- aumenta riesgo de carga no autorizada de contenido

**Score:** 8.5/10

### 6.5 Certificado SSL expirado y de otro dominio

El puerto `443/tcp` del servidor principal (`149.56.147.198`) sirve un certificado SSL con `commonName=autoboutiqueml.com` (dominio NO relacionado). Certificado expirado desde noviembre 2024. Los puertos `2083/tcp` y `2096/tcp` usan un certificado para `ip99.ip-51-79-9.net`.

**Impacto técnico:**
- certificado inválido para el dominio auditado
- expone a los usuarios a warnings de seguridad en el navegador
- sugiere configuración descuidada o hosting compartido mal configurado

**Impacto operativo:**
- degrada la confianza del sitio
- puede interferir con comunicaciones cifradas

**Score:** 7.0/10

### 6.6 Enumeración de usuarios en WordPress

La REST API expone usuarios, incluyendo `admin`.

**Impacto técnico:**
- reduce incertidumbre para ataques de autenticación
- permite targeting directo de cuentas reales
- facilita ingeniería social y brute force dirigido

**Impacto operativo:**
- aumenta exposición del portal institucional
- eleva riesgo del panel de administración

**Score:** 8.0/10

### 6.7 Imunify360 detectado (WAF)

Se identificó **Imunify360** como WAF/perímetro en el servidor principal. Bloquea REST API de WordPress, WPScan y curl directo. Sin embargo, los paneles administrativos (cPanel, Webmail) siguen expuestos públicamente.

**Impacto técnico:**
- el WAF existe pero es parcial: bloquea APIs pero no el acceso a paneles
- sugiere que la protección está orientada a WordPress, no a la infraestructura
- el WAF puede generar falsa sensación de seguridad

**Score:** 5.0/10 (existente pero insuficiente)

### 6.8 Sin rate limiting visible en autenticación

No se observó limitación fuerte en `wp-login.php`.

**Impacto técnico:**
- facilita brute force y credential stuffing
- permite automatización de ataques de autenticación
- reduce fricción para intentos repetidos

**Score:** 8.0/10

## 7. Hallazgos importantes

### 7.1 PHP 7.4.33 en Moodle + error crítico

La versión detectada está fuera de soporte (EOL desde Nov 2022). Además, el sitio expone errores PHP en producción:

```
Warning: mkdir(): Disk quota exceeded in /home/integridad/public_html/lib/classes/component.php on line 327
```

Esto revela:
- Ruta completa del servidor: `/home/integridad/public_html/`
- Problema de almacenamiento (Disk quota exceeded)
- El servidor está en modo producción con errores visibles

**Impacto técnico:**
- sin parches oficiales de seguridad
- path disclosure que facilita ataques dirigidos
- error de storage puede causar denegación de servicio parcial
- deuda técnica y exposición acumulada

**Impacto operativo:**
- el LMS puede fallar si no hay espacio en disco
- visibilidad de errores PHP en producción es mala práctica

**Score:** 9.0/10

### 7.2 Superficie completa de correo expuesta

Se observan servicios de POP3, IMAP, SMTPS y Submission.

**Impacto técnico:**
- múltiples vectores de autenticación
- incremento de abuso de cuentas
- superficie amplia para credenciales comprometidas

**Score:** 7.5/10

### 7.3 `webdisk` con autenticación básica

`webdisk.colegiointegridad.edu.pe` responde con Basic Auth.

**Impacto técnico:**
- servicio administrativo adicional visible desde Internet
- autenticación básica expuesta

**Score:** 6.5/10

### 7.4 `wp-admin/install.php` responde

El endpoint de instalación WordPress está accesible.

**Impacto técnico:**
- confirma exposición del stack de administración
- refuerza hardening pendiente

**Score:** 6.0/10

## 8. Evidencia

### Outputs de herramientas (almacenados en Kali: `~/colegio-integridad/`)

| Archivo | Contenido |
|---------|-----------|
| `dns/nslookup.txt` | Resolución del dominio → `149.56.147.198` |
| `dns/whois.txt` | Whois completo — registrante, admin, DNS |
| `dns/ns.txt` | Nameservers: `ns1.ip-158-69-7.net`, `ns2.ip-158-69-7.net` |
| `dns/a.txt` | Registro A: `149.56.147.198` |
| `dns/gobuster-dns.txt` | 7 subdominios descubiertos |
| `web/whatweb-main.txt` | Fingerprint WordPress 6.9.4, Apache, openresty/1.29.2.3 |
| `web/whatweb-aula.txt` | Fingerprint Moodle: LiteSpeed, PHP 7.4.33 |
| `web/headers-main.txt` | HTTP 200, Server: Apache, Link wp-json |
| `web/headers-aula.txt` | HTTP 503, PHP 7.4.33, LiteSpeed |
| `scans/host1.nmap` | Escaneo completo host1 — 13 puertos, servicios, versiones |
| `scans/host1.gnmap` | Formato grepeable |
| `scans/host2.nmap` | Host2 — todos los puertos filtrados |
| `scans/host2.gnmap` | Formato grepeable |

### Capturas finales (E01-E09)

| Código | Contenido | Archivo |
|--------|-----------|---------|
| E01 | nslookup + whois | `evidence/E01_nslookup_whois.txt` ✅ |
| E02 | Gobuster subdominios | `evidence/E02_gobuster_subdominios.txt` ✅ |
| E03 | Nmap host1 (puertos y servicios) | `evidence/E03_nmap_host1.txt` ✅ |
| E04 | Nmap host2 (filtrados) | `evidence/E04_nmap_host2.txt` ✅ |
| E05 | Whatweb WordPress 6.9.4 | `evidence/E05_whatweb_wordpress.txt` ✅ |
| E06 | Whatweb Moodle + PHP EOL + path disclosure | `evidence/E06_whatweb_moodle.txt` ✅ |
| E07 | cPanel login screenshot | `report/E07_cpanel.png` ✅ ![E07](report/E07_cpanel.png) |
| E08 | Webmail Roundcube screenshot | `report/E08_webmail.png` ✅ ![E08](report/E08_webmail.png) |
| E09 | Moodle error + path disclosure screenshot | `report/E09_moodle.png` ✅ ![E09](report/E09_moodle.png) |

### Hallazgos adicionales de última corrida (con internet restaurado)

| Hallazgo | Detalle | Estado |
|----------|---------|--------|
| Imunify360 WAF | Detectado bloqueando REST API de WP | ✅ Agregado |
| Moodle error path | `Disk quota exceeded` + path disclosure | ✅ Agregado |
| WP REST API | Bloqueado por Imunify360 — no se pudo enumerar usuarios | ❌ Bloqueado |
| WPScan | Abortado — openresty 415 bloquea el scanner | ❌ Bloqueado |
| openresty 415 | openresty/1.29.2.3 rechaza peticiones sin headers específicos | ✅ Observado |

### Notas

- Los outputs de herramientas están disponibles en `~/colegio-integridad/` dentro de la VM Kali (`192.168.122.50`)
- Las capturas E07-E08 requieren acceso HTTP/HTTPS (openresty 415 desde la Kali — probar desde el navegador del Arch)
- Se recomienda descargar los outputs desde Kali a la máquina anfitriona para adjuntarlos al entregable final

## 9. Riesgo

### Clasificación general

- **Exposición externa:** alta
- **Impacto potencial:** alto
- **Probabilidad de abuso:** media-alta
- **Madurez defensiva observada:** insuficiente

### Score preliminar general

**8.8/10**

## 10. Prioridad de remediación

### P1 - Inmediato

- restringir `2083/tcp` cPanel por VPN o allowlist IP
- restringir `2096/tcp` Webmail por VPN o allowlist IP
- mover `3306/tcp` (MariaDB 11.4.10) a red privada o localhost
- retirar `21/tcp` FTP (Pure-FTPd) o reemplazarlo por SFTP/FTPS controlado
- renovar/reemplazar certificado SSL (actualmente expirado y de otro dominio)
- habilitar MFA en accesos administrativos y correo

### P2 - Corto plazo

- habilitar WAF
- aplicar rate limiting en `wp-login.php`
- revisar `xmlrpc.php` si existe
- deshabilitar enumeración de usuarios por REST API si no aporta valor
- revisar hardening de correo (Dovecot + Exim) y exposición de buzones

### P3 - Mediano plazo

- actualizar PHP 7.4.33 en Moodle (EOL desde Nov 2022)
- revisar estabilidad del LMS (responde 503 consistentemente)
- validar y limpiar subdominios administrativos innecesarios (webdisk, cpcalendars, cpcontacts)
- formalizar monitoreo y alertas sobre accesos anómalos

## 11. Impacto de negocio

La exposición actual incrementa la probabilidad de:

- compromiso de credenciales
- afectación de correo institucional
- acceso no autorizado a bases de datos
- alteración de contenido web
- degradación de continuidad operativa

## 12. Recomendaciones

1. Segmentar administración, correo y base de datos fuera de exposición pública.
2. Mover MySQL a red privada y prohibir acceso directo desde Internet.
3. Reemplazar FTP por SFTP o mecanismos de despliegue controlados.
4. Implementar MFA para cPanel, Webmail y WordPress admin.
5. Agregar WAF o una capa equivalente de mitigación.
6. Limitar autenticación y enumeración en WordPress.
7. Actualizar o migrar el stack PHP del Moodle EOL.
8. Registrar evidencia, responsable y fecha objetivo para cada hallazgo.

## 13. Plan de remediación

### Fase 1 - Contención inmediata
- cerrar acceso público a cPanel y Webmail
- mover MySQL fuera de Internet
- retirar o aislar FTP
- activar MFA en administración

### Fase 2 - Endurecimiento perimetral
- habilitar WAF
- aplicar rate limiting
- revisar `xmlrpc.php`
- reducir enumeración de usuarios
- revisar hardening de correo

### Fase 3 - Saneamiento de plataforma
- actualizar PHP del LMS
- revisar estabilidad y errores
- limpiar subdominios innecesarios
- documentar activos y responsables

## 14. Conclusión

La infraestructura funciona, pero está demasiado expuesta para considerarse endurecida. La prioridad debe ser cerrar la superficie crítica y luego avanzar hacia remediación ordenada, monitoreo y saneamiento técnico.

## 15. Texto base para PPT

### Slide 1 - Portada
**Auditoría de superficie y exposición**
`colegiointegridad.edu.pe` / `aula.colegiointegridad.edu.pe`

### Slide 2 - Objetivo
Evaluar la exposición pública del entorno, identificar servicios críticos visibles desde Internet y priorizar remediación.

### Slide 3 - Resumen ejecutivo
El entorno presenta un riesgo alto por servicios administrativos expuestos, bases de datos públicas y controles defensivos insuficientes.

### Slide 4 - Alcance
Se evaluaron `149.56.147.198`, `51.161.45.249` y los subdominios activos asociados al dominio principal.

### Slide 5 - Superficie expuesta
WordPress, cPanel, Webmail, MySQL, FTP y Moodle forman la superficie principal observada.

### Slide 6 - Hallazgos críticos
- cPanel público
- Webmail público
- MySQL público
- FTP público
- enumeración de usuarios en WordPress

### Slide 7 - Hallazgos técnicos clave
- sin WAF visible
- sin rate limiting visible
- Moodle con PHP 7.4.33 EOL
- correo completo expuesto

### Slide 8 - Impacto
La exposición facilita abuso de credenciales, compromete correo institucional y aumenta el riesgo sobre datos y contenido web.

### Slide 9 - Prioridades
- P1: cerrar exposición crítica
- P2: endurecer perímetro y autenticación
- P3: actualizar y limpiar superficie

### Slide 10 - Recomendaciones
Bloquear paneles públicos, mover MySQL a red privada, activar MFA, habilitar WAF y aplicar rate limiting.

### Slide 11 - Cierre
La remediación debe empezar por administración, correo y base de datos para reducir el riesgo de forma inmediata.

## 16. Campos pendientes

- **Fecha:** `2026-05-11`
- **Autor / equipo:** `Samuel`
- **Evidencias/capturas finales:** ✅ Completas (E01-E09 en `/tmp/colegio-integridad/evidence/`)
- **Salidas reales de herramientas:** ✅ Almacenadas en `/tmp/colegio-integridad/`

## 17. Herramientas pendientes para completar el entregable

| Herramienta | Estado | Prioridad | Notas |
|------------|--------|-----------|-------|
| Shodan / Censys / ZoomEye | ❌ Pendiente | 🔵 Media | Buscar `149.56.147.198` y `51.161.45.249`. Se hace desde navegador. ~15 min |
| WAppalyzer | ❌ Pendiente | 🔵 Media | Extensión de navegador. Abrir `colegiointegridad.edu.pe` y `aula.colegiointegridad.edu.pe` |
| Nikto | ❌ Pendiente | 🔵 Media | `nikto -h colegiointegridad.edu.pe -ssl`. Desde Kali. ~15 min |
| WPScan | ❌ Bloqueado | 🔴 Alta | Imunify360 + openresty 415 bloquean. Probar con `--random-agent` o desde VPN distinta |
| Nessus / OpenVAS | ❌ No viable | ⚫ Baja | Kali tiene 2GB RAM — se cuelga. No recomendado |
| Burp Suite / OWASP ZAP | ❌ Pendiente | 🟢 Opcional | Navegar manualmente interceptando tráfico. Agrega screenshots |
| Explotación de hallazgos | ❌ Fuera de alcance | ⚠️ Legal | NO ejecutar sin autorización por escrito del cliente |
| Persistencia / Privilege Escalation | ❌ No aplica | ⚠️ Legal | Depende de explotación. No aplica en auditoría observacional |

## 18. Guía rápida para completar el entregable (mañana)

### Requisitos previos
- ✅ Kali corriendo con internet (`192.168.122.50`)
- ✅ Arch host con internet (`192.168.0.37`)
- ✅ Acceso SSH a Kali: `ssh sam@192.168.122.50` pass `samuel`
- ✅ Datos en `/tmp/colegio-integridad/`
- ✅ Evidencias en `/tmp/colegio-integridad/evidence/`

## 19. Checklist pentest completo (desde Parrot en clases)

```
Metodología: RECON → ENUM → EXPLOTACIÓN → PERSISTENCIA → DOC
Herramientas en Parrot: ✅ Metasploit ✅ msfvenom ✅ nikto ✅ nmap ✅ gobuster ✅ whatweb
```

### FASE 1 — RECONOCIMIENTO (ya tenemos todo)
```
☐ NS lookup / whois / dig                  → ✅ OK
☐ Gobuster DNS                             → ✅ OK
☐ Whatweb / nmap host1 + host2             → ✅ OK
☐ Subdominios (11)                         → ✅ OK
```

### FASE 2 — ENUMERACIÓN (desde Parrot)

#### ☐ 2A. Shodan + Censys + ZoomEye (15 min — navegador)
```
Abrí:
→ https://www.shodan.io/host/149.56.147.198
→ https://search.censys.io/hosts/149.56.147.198
→ https://www.zoomeye.org/searchResult?q=149.56.147.198
(lo mismo para 51.161.45.249)
```
Screenshot → `E10_shodan.png`, `E11_censys.png`, `E12_zoomeye.png`

#### ☐ 2B. WAppalyzer (5 min — navegador)
```
1. Instalá WAppalyzer en Firefox/Chrome
2. Abrí colegiointegridad.edu.pe y aula.colegiointegridad.edu.pe
3. Screenshot → E13_wappalyzer_main.png, E14_wappalyzer_aula.png
```

#### ☐ 2C. Nikto (15 min — Parrot)
```bash
nikto -h colegiointegridad.edu.pe -ssl -o nikto-main.txt
nikto -h aula.colegiointegridad.edu.pe -ssl -o nikto-aula.txt
nikto -h cpanel.colegiointegridad.edu.pe -port 2083 -ssl -o nikto-cpanel.txt
nikto -h webmail.colegiointegridad.edu.pe -port 2096 -ssl -o nikto-webmail.txt
```

#### ☐ 2D. WPScan con evasión (10 min — Parrot)
```bash
wpscan --url https://colegiointegridad.edu.pe --random-user-agent --enumerate u
```
Si bloquea: `--stealthy` o `proxychains wpscan ...`

#### ☐ 2E. Burp Suite / OWASP ZAP (30 min — Parrot)
```
1. Abrí Burp Suite o ZAP
2. Configurá proxy en el navegador
3. Navegá a todos los subdominios
4. Revisá: headers, cookies, parámetros, formularios
5. Guardá capturas de:
   - Login de cPanel (cpanel.colegiointegridad.edu.pe:2083)
   - Login de Webmail (webmail.colegiointegridad.edu.pe:2096)
   - Moodle (aula.colegiointegridad.edu.pe)
   - WordPress (colegiointegridad.edu.pe)
```

### FASE 3 — EXPLOTACIÓN (PoC controlado — con permiso ✅)

#### ☐ 3A. MariaDB expuesto (3306) — probar acceso sin auth
```bash
# Desde Parrot (o desde Arch)
mysql -h 149.56.147.198 -u root -p
mysql -h 149.56.147.198 -u admin -p
# Probar conexión sin contraseña
mysql -h 149.56.147.198 -u root
```
Si conecta → capturá el banner como evidencia crítica.

#### ☐ 3B. FTP anónimo (21)
```bash
ftp 149.56.147.198
# User: anonymous, Pass: anonymous
# Si conecta → capturá el listado de archivos
```

#### ☐ 3C. WordPress — fuerza bruta (solo si no hay rate limiting)
```bash
wpscan --url https://colegiointegridad.edu.pe --passwords /usr/share/wordlists/rockyou.txt --usernames admin
# O usá hydra contra wp-login.php
hydra -l admin -P /usr/share/wordlists/rockyou.txt 149.56.147.198 https-post-form "/wp-login.php:log=^USER^&pwd=^PASS^&wp-submit=Iniciar sesión:El nombre de usuario o la contraseña son incorrectos"
```

#### ☐ 3D. Moodle — versión PHP EOL (7.4.33)
```
Buscar explotación pública para Moodle + PHP 7.4.33:
searchsploit moodle
searchsploit php 7.4
```

#### ☐ 3E. Metasploit — escaneo auxiliar
```bash
msfconsole -q
# Escaneo auxiliar MySQL
use auxiliary/scanner/mysql/mysql_version
use auxiliary/scanner/mysql/mysql_login
set RHOSTS 149.56.147.198
run

# Escaneo auxiliar FTP
use auxiliary/scanner/ftp/ftp_version
set RHOSTS 149.56.147.198
run

# Escaneo auxiliar WordPress
use auxiliary/scanner/http/wordpress_scanner
set RHOSTS 149.56.147.198
run
```

### FASE 4 — MANTENER ACCESO (documentación teórica)

```
⚠️ Esto es SOLO documentación de riesgo — no ejecutar en producción.

Vectores identificados que podrían usarse para persistencia:
- Si MariaDB tiene credenciales débiles → obtener credenciales de WP/Moodle
- Si cPanel es comprometido → acceso total al hosting
- Si Webmail es comprometido → acceso a correo institucional
- Si FTP permite subida → webshell en WordPress

Esto se documenta en el informe como "riesgo potencial", no se ejecuta.
```

### FASE 5 — DOCUMENTACIÓN (todo desde Parrot)

#### ☐ 5A. Armar PPT (30 min)
```
Usando las 11 slides de la Sección 15 + nuevas:

☐ Slide 1 — Portada (colegiointegridad.edu.pe)
☐ Slide 2 — Objetivo y alcance
☐ Slide 3 — Resumen ejecutivo (riesgo 8.8/10 ALTO)
☐ Slide 4 — Metodología (recon → enum → explotación)
☐ Slide 5 — Superficie expuesta (mapa de puertos)
☐ Slide 6 — Hallazgos críticos (MySQL, cPanel, Webmail, FTP)
☐ Slide 7 — Hallazgos técnicos (cert expirado, Imunify360, Moodle EOL)
☐ Slide 8 — Explotación validada (lo que se pudo probar)
☐ Slide 9 — Impacto y riesgo
☐ Slide 10 — Prioridades y remediación
☐ Slide 11 — Cierre y próximos pasos
```

#### ☐ 5B. Armar PDF (30 min)
```
1. Exportá entregable_colegio_integridad.md → PDF
2. Verificá imágenes embebidas
3. Agregá carátula (logo, fecha: 2026-05-11, autor: Samuel)
4. Revisá ortografía
```

#### ☐ 5C. Llevar datos al Parrot (opcional)
```bash
scp -r sam@192.168.0.37:/tmp/colegio-integridad/ ~/
```

### Notas finales
- ✅ Permiso del colegio y equipo de desarrollo confirmado
- ✅ Datos base completos en Obsidian `entregable_colegio_integridad.md`
- ⚠️ Explotación: solo PoC controlado, NO modificar datos productivos
- ⚠️ Si conecta a MySQL/FTP → documentar, no alterar nada

### Estado de los datos de reconocimiento

| Ítem | Estado | Notas |
|------|--------|-------|
| DNS / WHOIS | ✅ Completo | nslookup, whois, dig NS, dig A |
| Subdominios | ✅ Completo | Gobuster DNS — 7 encontrados |
| Fingerprinting | ✅ Completo | Whatweb main + aula, headers |
| Nmap host1 | ✅ Completo | 13 puertos, versiones, scripts |
| Nmap host2 | ✅ Completo | Todos filtrados (firewall) |
| WP users | ❌ Bloqueado | Imunify360 bloquea REST API |
| WPScan | ❌ Bloqueado | openresty 415 + Imunify360 |
| cPanel/webmail headers | ❌ Bloqueado | openresty 415 (intentar desde navegador Arch) |
| Moodle path disclosure | ✅ Nuevo | `Disk quota exceeded` + ruta del servidor |
| Imunify360 detectado | ✅ Confirmado | WAF presente en WordPress |
| Capturas E01-E09 | ✅ Completas | 6 txt + 3 png en `evidence/` |
| Fecha | ❌ Pendiente | |
| Autor/equipo | ❌ Pendiente | |
